# CUDA Ray Tracer

A simple ray tracer built with C++ and NVIDIA CUDA. The project demonstrates how a graphics workload can be parallelized on a GPU by assigning one CUDA thread to each pixel.

The program supports both CPU and CUDA GPU rendering, making it possible to compare the execution time of the two approaches.

## Project Overview

The renderer creates a 3D scene containing several spheres and light sources. For every pixel, a ray is generated from the camera and traced through the scene.

The renderer calculates:

- Ray-sphere intersections
- Diffuse lighting
- Specular highlights
- Shadows
- Reflections
- Final pixel colors

The GPU implementation performs these calculations in parallel using CUDA.

## Technologies

- C++
- CUDA
- NVIDIA `nvcc`
- Visual Studio 2022 Build Tools
- CUDA C++
- PPM image format

## Hardware Used

The project was tested on:

- GPU: NVIDIA GeForce MX550
- GPU Memory: 2 GB
- NVIDIA Driver: 581.83
- CUDA Toolkit: 13.4
- CUDA Architecture: `sm_75`
- Operating System: Windows

## How CUDA Is Used

The main GPU implementation is located in:

    src/renderer.cu

The renderer uses a CUDA kernel called `renderKernel`.

Each CUDA thread is responsible for calculating one pixel.

The kernel uses 16 × 16 thread blocks:

```cpp
dim3 block(16, 16);
```

The pixel coordinates are calculated from the CUDA block and thread indices:

```cpp
int x =
    blockIdx.x * blockDim.x +
    threadIdx.x;

int y =
    blockIdx.y * blockDim.y +
    threadIdx.y;
```

For every pixel, the CUDA thread:

1. Generates a camera ray.
2. Tests the ray against the spheres.
3. Finds the closest intersection.
4. Calculates lighting.
5. Checks for shadows.
6. Calculates reflections.
7. Stores the final color in the framebuffer.

This allows many pixels to be processed simultaneously by the GPU.

## CPU Implementation

The project also contains a CPU renderer.

The CPU implementation uses nested loops over:

- Image height
- Image width
- Samples per pixel

The CPU and GPU renderers use the same basic ray-tracing logic.

This allows the project to compare the execution time of CPU and GPU rendering.

## Project Structure

    cuda-raytracer/
    |
    +-- src/
    |   +-- main.cu
    |   +-- math.cuh
    |   +-- ray.cuh
    |   +-- renderer.cu
    |   +-- renderer.cuh
    |   +-- scene.cuh
    |
    +-- output/
    |   +-- cpu.ppm
    |   +-- gpu.ppm
    |
    +-- benchmarks/
    |   +-- results.csv
    |
    +-- screenshots/
    |
    +-- build.bat
    +-- run.bat
    +-- README.md
    +-- .gitignore

## Source Files

### `main.cu`

Contains:

- Command-line argument handling
- Scene creation
- Camera setup
- CPU/GPU renderer selection
- Execution timing
- PPM image output

### `renderer.cu`

Contains:

- Ray-sphere intersection
- Closest-hit calculation
- Shadow calculation
- Ray tracing
- CUDA kernel
- GPU memory allocation
- GPU memory transfers
- CPU rendering implementation

### `renderer.cuh`

Contains the renderer declarations and rendering configuration.

### `scene.cuh`

Contains the scene objects:

- Spheres
- Lights
- Camera

### `ray.cuh`

Contains the ray representation and ray operations.

### `math.cuh`

Contains vector and mathematical operations used by the renderer.

## Requirements

To build the project, the following are required:

- Windows
- NVIDIA GPU
- NVIDIA CUDA Toolkit
- CUDA `nvcc` compiler
- Visual Studio 2022 or Visual Studio 2022 Build Tools
- C++17 support

## Building the Project

On Windows, open:

    x64 Native Tools Command Prompt for VS 2022

The Native Tools Command Prompt is used because `nvcc` requires Microsoft's `cl.exe` C++ compiler.

Navigate to the project directory:

```cmd
cd C:\Users\workk\serious\cuda-raytracer
```

Build the project:

```cmd
build.bat
```

The build script uses:

```cmd
nvcc -O3 -std=c++17 -arch=sm_75 src\main.cu src\renderer.cu -o cuda_raytracer.exe
```

After a successful build, the executable is created as:

    cuda_raytracer.exe

## Manual Build

The program can also be compiled manually:

```cmd
nvcc -O3 -std=c++17 -arch=sm_75 src\main.cu src\renderer.cu -o cuda_raytracer.exe
```

## Running the GPU Renderer

The CUDA GPU renderer can be executed with:

```cmd
cuda_raytracer.exe --gpu --width 1280 --height 720 --samples 10 --bounces 3 --output output\gpu.ppm
```

Example output:

    CUDA Ray Tracer
    Resolution: 1280x720
    Samples: 10
    Bounces: 3

    Renderer: CUDA GPU
    Render time: 312.761 ms
    Output: output\gpu.ppm

## Running the CPU Renderer

The CPU renderer can be executed with:

```cmd
cuda_raytracer.exe --cpu --width 1280 --height 720 --samples 10 --bounces 3 --output output\cpu.ppm
```

Example output:

    CUDA Ray Tracer
    Resolution: 1280x720
    Samples: 10
    Bounces: 3

    Renderer: CPU
    Render time: 5397.780 ms
    Output: output\cpu.ppm

## Command-Line Options

The program supports the following options:

    --width N
        Set image width.

    --height N
        Set image height.

    --samples N
        Set the number of samples per pixel.

    --bounces N
        Set the maximum number of reflection bounces.

    --output FILE
        Specify the output PPM file.

    --cpu
        Use the CPU renderer.

    --gpu
        Use the CUDA GPU renderer.

    --help
        Display command-line usage information.

## Scene

The scene contains several spheres with different:

- Positions
- Sizes
- Colors
- Reflectivity
- Specular values

Two light sources are used to illuminate the scene.

The camera is positioned in front of the objects and generates rays through the image plane.

## Rendering Process

The rendering process can be summarized as:

    Camera
       |
       v
    Generate Ray
       |
       v
    Test Sphere Intersections
       |
       v
    Find Closest Hit
       |
       v
    Calculate Lighting
       |
       v
    Shadow Test
       |
       v
    Calculate Reflection
       |
       v
    Store Pixel Color
       |
       v
    Write PPM Image

## GPU Memory

The GPU renderer allocates device memory for:

- Framebuffer
- Sphere data
- Light data

Scene information is copied from CPU memory to GPU memory before the CUDA kernel is executed.

After rendering finishes, the framebuffer is copied from GPU memory back to CPU memory and written to a PPM image.

The basic process is:

    CPU Memory
         |
         | cudaMemcpy
         v
    GPU Memory
         |
         | CUDA Kernel
         v
    GPU Framebuffer
         |
         | cudaMemcpy
         v
    CPU Memory
         |
         v
      PPM File

## CUDA Thread Organization

The renderer uses:

```cpp
dim3 block(16, 16);
```

Each block therefore contains 256 threads.

For an image such as 1280 × 720, the CUDA grid is calculated from the image dimensions so that every pixel has a corresponding CUDA thread.

Threads outside the image dimensions exit without performing any work.

## Performance Test

A CPU and GPU comparison was performed using the same scene and rendering settings.

Test configuration:

    Resolution: 1280 × 720
    Samples:    10
    Bounces:    3

Measured execution times:

    CPU: 5397.780 ms
    GPU:  312.761 ms

The measured GPU execution time was approximately 17.3 times lower than the CPU execution time for this particular test.

These measurements depend on the hardware, operating system, background processes, compiler settings, scene, and rendering configuration.

The benchmark data is stored in:

    benchmarks/results.csv

## Example Output Files

The project generates PPM image files:

    output/
    ├── cpu.ppm
    └── gpu.ppm

The CPU and GPU renderers produce the same type of scene output.

## Challenges

One challenge during development was configuring the CUDA compiler on Windows.

`nvcc` requires the Microsoft C++ compiler `cl.exe`. The project therefore needs to be built from the Visual Studio Native Tools Command Prompt.

Another challenge was selecting a CUDA architecture compatible with the GPU used for testing.

The final build uses:

    -arch=sm_75

The project also required managing memory between the CPU and GPU and synchronizing the CUDA kernel before retrieving the rendered framebuffer.

## Lessons Learned

This project provided practical experience with:

- CUDA kernel development
- CUDA thread and block organization
- GPU memory allocation
- Host-to-device memory transfers
- Device-to-host memory transfers
- CUDA kernel synchronization
- Ray-sphere intersection
- GPU-based lighting calculations
- GPU-based reflection calculations
- CPU versus GPU performance measurement

The project also demonstrated why workloads containing many independent calculations can be mapped effectively to GPU threads.

## Limitations

This is a simple educational ray tracer.

Current limitations include:

- Only spheres are supported as scene geometry.
- The scene is defined directly in the source code.
- Lighting uses a simple lighting model.
- Reflections use a simple bounce-based approach.
- Output is written as PPM.
- No textures are currently supported.
- No acceleration structure such as a BVH is used.
- No advanced physically based materials are implemented.

## Conclusion

This project demonstrates a simple ray tracer implemented with C++ and NVIDIA CUDA.

The main GPU technique is assigning one CUDA thread to each image pixel. Each thread independently performs ray generation, intersection testing, lighting, shadow calculations, and reflection calculations.

A CPU implementation is also included to provide a direct comparison with the CUDA implementation.

The project demonstrates practical GPU programming concepts including CUDA kernels, thread organization, GPU memory management, host-device transfers, synchronization, and parallel computation.

## Author
CUDA Ray Tracer
GPU Specialization Capstone Project
