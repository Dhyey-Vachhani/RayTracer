@echo off

if not exist output mkdir output

cuda_raytracer.exe ^
    --gpu ^
    --width 1280 ^
    --height 720 ^
    --samples 10 ^
    --bounces 3 ^
    --output output\gpu.ppm

pause
