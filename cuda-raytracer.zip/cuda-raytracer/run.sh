#!/usr/bin/env bash

set -e

mkdir -p output
mkdir -p benchmarks

make

if [ "$1" = "benchmark" ]; then

    echo "Running CPU benchmark..."

    ./cuda_raytracer \
        --cpu \
        --width 800 \
        --height 600 \
        --samples 10 \
        --bounces 3 \
        --output output/cpu_800x600.ppm

    echo "Running GPU benchmark..."

    ./cuda_raytracer \
        --gpu \
        --width 800 \
        --height 600 \
        --samples 10 \
        --bounces 3 \
        --output output/gpu_800x600.ppm

    echo "Running larger GPU render..."

    ./cuda_raytracer \
        --gpu \
        --width 1920 \
        --height 1080 \
        --samples 50 \
        --bounces 5 \
        --output output/gpu_1920x1080.ppm

else

    ./cuda_raytracer \
        --gpu \
        --width 800 \
        --height 600 \
        --samples 10 \
        --bounces 3 \
        --output output/render.ppm

fi
