@echo off

echo Building CUDA Ray Tracer...

nvcc -O3 -std=c++17 -arch=sm_75 ^
    src\main.cu src\renderer.cu ^
    -o cuda_raytracer.exe

if %ERRORLEVEL% NEQ 0 (
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build successful!
pause
