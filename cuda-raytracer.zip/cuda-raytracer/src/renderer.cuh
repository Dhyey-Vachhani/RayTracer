#pragma once

#include "scene.cuh"

struct RenderConfig
{
    int width;
    int height;
    int samples;
    int maxBounces;
};

void renderCPU(
    Vec3 *framebuffer,
    const Sphere *spheres,
    int sphereCount,
    const Light *lights,
    int lightCount,
    const Camera &camera,
    const RenderConfig &config);

void renderGPU(
    Vec3 *framebuffer,
    const Sphere *spheres,
    int sphereCount,
    const Light *lights,
    int lightCount,
    const Camera &camera,
    const RenderConfig &config);
