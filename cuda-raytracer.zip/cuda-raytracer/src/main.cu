#include "renderer.cuh"

#include <cuda_runtime.h>

#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace
{

    struct Options
    {
        int width = 800;
        int height = 600;
        int samples = 10;
        int bounces = 3;

        std::string output = "output/render.ppm";

        bool cpu = false;
        bool gpu = true;
        bool benchmark = false;
    };

    void printUsage(const char *program)
    {
        std::cout
            << "CUDA Ray Tracer\n\n"
            << "Usage:\n"
            << "  " << program << " [options]\n\n"
            << "Options:\n"
            << "  --width N       Image width\n"
            << "  --height N      Image height\n"
            << "  --samples N     Samples per pixel\n"
            << "  --bounces N     Maximum reflection bounces\n"
            << "  --output FILE   Output PPM file\n"
            << "  --cpu           Use CPU renderer\n"
            << "  --gpu           Use CUDA renderer\n"
            << "  --benchmark     Run benchmark\n"
            << "  --help          Show this message\n";
    }

    bool parseInt(
        const char *value,
        int &result)
    {

        try
        {
            result = std::stoi(value);
            return result > 0;
        }
        catch (...)
        {
            return false;
        }
    }

    bool parseArguments(
        int argc,
        char **argv,
        Options &options)
    {

        for (int i = 1; i < argc; ++i)
        {

            std::string arg(argv[i]);

            if (arg == "--help")
            {
                printUsage(argv[0]);
                return false;
            }

            if (arg == "--cpu")
            {
                options.cpu = true;
                options.gpu = false;
                continue;
            }

            if (arg == "--gpu")
            {
                options.gpu = true;
                options.cpu = false;
                continue;
            }

            if (arg == "--benchmark")
            {
                options.benchmark = true;
                continue;
            }

            if (i + 1 >= argc)
            {
                std::cerr
                    << "Missing value for "
                    << arg << '\n';
                return false;
            }

            if (arg == "--width")
            {
                if (!parseInt(argv[++i], options.width))
                {
                    return false;
                }
            }
            else if (arg == "--height")
            {
                if (!parseInt(argv[++i], options.height))
                {
                    return false;
                }
            }
            else if (arg == "--samples")
            {
                if (!parseInt(argv[++i], options.samples))
                {
                    return false;
                }
            }
            else if (arg == "--bounces")
            {
                if (!parseInt(argv[++i], options.bounces))
                {
                    return false;
                }
            }
            else if (arg == "--output")
            {
                options.output = argv[++i];
            }
            else
            {
                std::cerr
                    << "Unknown argument: "
                    << arg << '\n';
                return false;
            }
        }

        return true;
    }

    void createScene(
        std::vector<Sphere> &spheres,
        std::vector<Light> &lights,
        Camera &camera)
    {

        spheres.push_back(
            Sphere(
                Vec3(0.0f, 0.0f, -5.0f),
                1.0f,
                Vec3(0.8f, 0.15f, 0.1f),
                0.35f,
                0.8f));

        spheres.push_back(
            Sphere(
                Vec3(2.2f, 0.3f, -6.0f),
                1.3f,
                Vec3(0.1f, 0.3f, 0.85f),
                0.20f,
                0.7f));

        spheres.push_back(
            Sphere(
                Vec3(-2.0f, -0.3f, -4.0f),
                0.7f,
                Vec3(0.15f, 0.8f, 0.25f),
                0.55f,
                0.6f));

        spheres.push_back(
            Sphere(
                Vec3(0.0f, -1002.0f, -5.0f),
                1000.0f,
                Vec3(0.55f, 0.55f, 0.55f),
                0.1f,
                0.3f));

        lights.push_back({Vec3(-4.0f, 6.0f, 2.0f),
                          Vec3(1.0f, 0.9f, 0.8f),
                          1.5f});

        lights.push_back({Vec3(5.0f, 3.0f, 1.0f),
                          Vec3(0.6f, 0.7f, 1.0f),
                          0.8f});

        camera.position =
            Vec3(0.0f, 1.0f, 2.0f);

        camera.forward =
            normalize(
                Vec3(0.0f, 0.0f, -5.0f) -
                camera.position);

        camera.right =
            normalize(
                cross(
                    camera.forward,
                    Vec3(0.0f, 1.0f, 0.0f)));

        camera.up =
            normalize(
                cross(
                    camera.right,
                    camera.forward));

        camera.fov =
            60.0f *
            3.14159265359f /
            180.0f;
    }

    void writePPM(
        const std::string &filename,
        const Vec3 *framebuffer,
        int width,
        int height)
    {

        std::ofstream file(filename);

        if (!file)
        {
            throw std::runtime_error(
                "Could not open output file");
        }

        file << "P3\n";
        file << width << ' ' << height << '\n';
        file << "255\n";

        for (int y = 0; y < height; ++y)
        {
            for (int x = 0; x < width; ++x)
            {

                Vec3 color =
                    framebuffer[y * width + x];

                color = clampColor(color);

                int r =
                    static_cast<int>(
                        color.x * 255.0f);

                int g =
                    static_cast<int>(
                        color.y * 255.0f);

                int b =
                    static_cast<int>(
                        color.z * 255.0f);

                file << r << ' '
                     << g << ' '
                     << b << '\n';
            }
        }
    }

    double milliseconds(
        const std::chrono::high_resolution_clock::time_point &start,
        const std::chrono::high_resolution_clock::time_point &end)
    {

        return std::chrono::duration<double, std::milli>(
                   end - start)
            .count();
    }

} // namespace

int main(int argc, char **argv)
{

    Options options;

    if (!parseArguments(
            argc,
            argv,
            options))
    {
        return 0;
    }

    std::vector<Sphere> spheres;
    std::vector<Light> lights;
    Camera camera;

    createScene(
        spheres,
        lights,
        camera);

    RenderConfig config{
        options.width,
        options.height,
        options.samples,
        options.bounces};

    const size_t pixelCount =
        static_cast<size_t>(
            config.width) *
        config.height;

    std::vector<Vec3> framebuffer(
        pixelCount);

    std::cout
        << "CUDA Ray Tracer\n"
        << "Resolution: "
        << config.width
        << "x"
        << config.height
        << '\n'
        << "Samples: "
        << config.samples
        << '\n'
        << "Bounces: "
        << config.maxBounces
        << "\n\n";

    auto start =
        std::chrono::high_resolution_clock::now();

    if (options.cpu)
    {

        std::cout
            << "Renderer: CPU\n";

        renderCPU(
            framebuffer.data(),
            spheres.data(),
            static_cast<int>(
                spheres.size()),
            lights.data(),
            static_cast<int>(
                lights.size()),
            camera,
            config);
    }
    else
    {

        std::cout
            << "Renderer: CUDA GPU\n";

        renderGPU(
            framebuffer.data(),
            spheres.data(),
            static_cast<int>(
                spheres.size()),
            lights.data(),
            static_cast<int>(
                lights.size()),
            camera,
            config);
    }

    auto end =
        std::chrono::high_resolution_clock::now();

    double elapsed =
        milliseconds(start, end);

    std::cout
        << std::fixed
        << std::setprecision(3)
        << "Render time: "
        << elapsed
        << " ms\n";

    writePPM(
        options.output,
        framebuffer.data(),
        config.width,
        config.height);

    std::cout
        << "Output: "
        << options.output
        << '\n';

    return 0;
}
