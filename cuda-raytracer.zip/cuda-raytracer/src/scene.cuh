#pragma once

#include "math.cuh"
#include "ray.cuh"

struct Sphere
{
    Vec3 center;
    float radius;

    Vec3 color;
    float reflectivity;
    float specular;

    __host__ __device__
    Sphere()
        : center(),
          radius(1.0f),
          color(1.0f, 1.0f, 1.0f),
          reflectivity(0.0f),
          specular(0.5f)
    {
    }

    __host__ __device__
    Sphere(
        const Vec3 &c,
        float r,
        const Vec3 &col,
        float refl,
        float spec)
        : center(c),
          radius(r),
          color(col),
          reflectivity(refl),
          specular(spec)
    {
    }
};

struct Light
{
    Vec3 position;
    Vec3 color;
    float intensity;
};

struct Camera
{
    Vec3 position;
    Vec3 forward;
    Vec3 right;
    Vec3 up;

    float fov;

    __host__ __device__
        Ray
        getRay(
            int pixelX,
            int pixelY,
            int width,
            int height) const
    {
        float aspect =
            static_cast<float>(width) /
            static_cast<float>(height);

        float scale =
            tanf(fov * 0.5f);

        float screenX =
            ((pixelX + 0.5f) / width * 2.0f - 1.0f) * aspect * scale;

        float screenY =
            (1.0f -
             (pixelY + 0.5f) / height * 2.0f) *
            scale;

        Vec3 direction =
            normalize(
                forward +
                right * screenX +
                up * screenY);

        return Ray(
            position,
            direction);
    }
};
