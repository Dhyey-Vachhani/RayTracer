#pragma once

#include <cmath>

struct Vec3 {
    float x;
    float y;
    float z;

    __host__ __device__
    Vec3() : x(0.0f), y(0.0f), z(0.0f) {}

    __host__ __device__
    Vec3(float x_, float y_, float z_)
        : x(x_), y(y_), z(z_) {}

    __host__ __device__
    Vec3 operator+(const Vec3& b) const {
        return Vec3(x + b.x, y + b.y, z + b.z);
    }

    __host__ __device__
    Vec3 operator-(const Vec3& b) const {
        return Vec3(x - b.x, y - b.y, z - b.z);
    }

    __host__ __device__
    Vec3 operator-() const{
        return Vec3(-x, -y, -z);
    }

    __host__ __device__
    Vec3 operator*(float s) const {
        return Vec3(x * s, y * s, z * s);
    }

    __host__ __device__
    Vec3 operator/(float s) const {
        return Vec3(x / s, y / s, z / s);
    }

    __host__ __device__
    Vec3& operator+=(const Vec3& b) {
        x += b.x;
        y += b.y;
        z += b.z;
        return *this;
    }

    __host__ __device__
    Vec3& operator*=(float s) {
        x *= s;
        y *= s;
        z *= s;
        return *this;
    }
};

__host__ __device__
inline Vec3 operator*(float s, const Vec3& v) {
    return v * s;
}

__host__ __device__
inline float dot(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

__host__ __device__
inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}

__host__ __device__
inline float length(const Vec3& v) {
    return sqrtf(dot(v, v));
}

__host__ __device__
inline Vec3 normalize(const Vec3& v) {
    float len = length(v);

    if (len <= 0.0f) {
        return Vec3();
    }

    return v / len;
}

__host__ __device__
inline Vec3 reflect(const Vec3& v, const Vec3& normal) {
    return v - normal * (2.0f * dot(v, normal));
}

__host__ __device__
inline Vec3 clampColor(const Vec3& c) {
    return Vec3(
        fminf(fmaxf(c.x, 0.0f), 1.0f),
        fminf(fmaxf(c.y, 0.0f), 1.0f),
        fminf(fmaxf(c.z, 0.0f), 1.0f)
    );
}
