#include "renderer.cuh"

#include <cuda_runtime.h>

#include <cmath>
#include <cstdlib>
#include <iostream>

namespace
{

    constexpr float kEpsilon = 0.001f;
    constexpr float kInfinity = 1.0e30f;

    struct HitRecord
    {
        float t;
        Vec3 point;
        Vec3 normal;
        Vec3 color;
        float reflectivity;
        float specular;
        bool hit;
    };

    __host__ __device__ bool intersectSphere(
        const Ray &ray,
        const Sphere &sphere,
        float &t)
    {
        Vec3 oc =
            ray.origin - sphere.center;

        float a =
            dot(
                ray.direction,
                ray.direction);

        float b =
            2.0f *
            dot(
                oc,
                ray.direction);

        float c =
            dot(oc, oc) -
            sphere.radius *
                sphere.radius;

        float discriminant =
            b * b -
            4.0f * a * c;

        if (discriminant < 0.0f)
        {
            return false;
        }

        float sqrtDiscriminant =
            sqrtf(discriminant);

        float t0 =
            (-b - sqrtDiscriminant) /
            (2.0f * a);

        float t1 =
            (-b + sqrtDiscriminant) /
            (2.0f * a);

        if (t0 > kEpsilon)
        {
            t = t0;
            return true;
        }

        if (t1 > kEpsilon)
        {
            t = t1;
            return true;
        }

        return false;
    }

    __host__ __device__
        HitRecord
        findClosestHit(
            const Ray &ray,
            const Sphere *spheres,
            int sphereCount)
    {
        HitRecord record;

        record.t = kInfinity;
        record.hit = false;

        for (int i = 0;
             i < sphereCount;
             ++i)
        {
            float t;

            if (intersectSphere(
                    ray,
                    spheres[i],
                    t))
            {
                if (t < record.t)
                {
                    record.t = t;
                    record.hit = true;

                    record.point =
                        ray.at(t);

                    record.normal =
                        normalize(
                            record.point -
                            spheres[i].center);

                    record.color =
                        spheres[i].color;

                    record.reflectivity =
                        spheres[i].reflectivity;

                    record.specular =
                        spheres[i].specular;
                }
            }
        }

        return record;
    }

    __host__ __device__ bool isShadowed(
        const Vec3 &point,
        const Vec3 &lightPosition,
        const Sphere *spheres,
        int sphereCount)
    {
        Vec3 toLight =
            lightPosition - point;

        float distanceToLight =
            length(toLight);

        Vec3 direction =
            normalize(toLight);

        Ray shadowRay(
            point +
                direction * kEpsilon,
            direction);

        for (int i = 0;
             i < sphereCount;
             ++i)
        {
            float t;

            if (intersectSphere(
                    shadowRay,
                    spheres[i],
                    t))
            {
                if (t < distanceToLight)
                {
                    return true;
                }
            }
        }

        return false;
    }

    __host__ __device__
        Vec3
        traceRay(
            const Ray &initialRay,
            const Sphere *spheres,
            int sphereCount,
            const Light *lights,
            int lightCount,
            int maxBounces)
    {
        Ray ray = initialRay;

        Vec3 accumulated(
            0.0f,
            0.0f,
            0.0f);

        Vec3 attenuation(
            1.0f,
            1.0f,
            1.0f);

        for (int bounce = 0;
             bounce <= maxBounces;
             ++bounce)
        {
            HitRecord hit =
                findClosestHit(
                    ray,
                    spheres,
                    sphereCount);

            if (!hit.hit)
            {
                Vec3 sky(
                    0.08f,
                    0.12f,
                    0.20f);

                accumulated +=
                    Vec3(
                        sky.x * attenuation.x,
                        sky.y * attenuation.y,
                        sky.z * attenuation.z);

                break;
            }

            Vec3 localColor(
                0.0f,
                0.0f,
                0.0f);

            for (int i = 0;
                 i < lightCount;
                 ++i)
            {
                const Light &light =
                    lights[i];

                Vec3 toLight =
                    normalize(
                        light.position -
                        hit.point);

                float diffuse =
                    fmaxf(
                        dot(
                            hit.normal,
                            toLight),
                        0.0f);

                if (!isShadowed(
                        hit.point,
                        light.position,
                        spheres,
                        sphereCount))
                {
                    // Diffuse lighting.
                    localColor +=
                        hit.color *
                        diffuse *
                        light.intensity;

                    Vec3 viewDirection =
                        normalize(
                            ray.origin -
                            hit.point);

                    Vec3 reflectedLight =
                        reflect(
                            -1.0f * toLight,
                            hit.normal);

                    float spec =
                        powf(
                            fmaxf(
                                dot(
                                    viewDirection,
                                    reflectedLight),
                                0.0f),
                            32.0f);

                    // Specular lighting.
                    localColor +=
                        Vec3(
                            1.0f,
                            1.0f,
                            1.0f) *
                        spec *
                        hit.specular *
                        light.intensity;
                }
            }

            // Small ambient contribution.
            localColor +=
                hit.color * 0.05f;

            accumulated +=
                Vec3(
                    localColor.x *
                        attenuation.x,
                    localColor.y *
                        attenuation.y,
                    localColor.z *
                        attenuation.z);

            if (hit.reflectivity <= 0.0f ||
                bounce == maxBounces)
            {
                break;
            }

            attenuation *=
                hit.reflectivity;

            Vec3 reflectedDirection =
                normalize(
                    reflect(
                        ray.direction,
                        hit.normal));

            ray = Ray(
                hit.point +
                    reflectedDirection *
                        kEpsilon,
                reflectedDirection);
        }

        return clampColor(
            accumulated);
    }

    void checkCuda(
        cudaError_t result,
        const char *operation)
    {
        if (result != cudaSuccess)
        {
            std::cerr
                << "CUDA error during "
                << operation
                << ": "
                << cudaGetErrorString(result)
                << '\n';

            std::exit(
                EXIT_FAILURE);
        }
    }

    __global__ void renderKernel(
        Vec3 *framebuffer,
        const Sphere *spheres,
        int sphereCount,
        const Light *lights,
        int lightCount,
        Camera camera,
        int width,
        int height,
        int samples,
        int maxBounces)
    {
        int x =
            blockIdx.x *
                blockDim.x +
            threadIdx.x;

        int y =
            blockIdx.y *
                blockDim.y +
            threadIdx.y;

        if (x >= width ||
            y >= height)
        {
            return;
        }

        Vec3 color(
            0.0f,
            0.0f,
            0.0f);

        // Each CUDA thread renders one pixel.
        for (int sample = 0;
             sample < samples;
             ++sample)
        {
            Ray ray =
                camera.getRay(
                    x,
                    y,
                    width,
                    height);

            color +=
                traceRay(
                    ray,
                    spheres,
                    sphereCount,
                    lights,
                    lightCount,
                    maxBounces);
        }

        color =
            color /
            static_cast<float>(
                samples);

        framebuffer[y * width + x] =
            clampColor(color);
    }

} // namespace

void renderCPU(
    Vec3 *framebuffer,
    const Sphere *spheres,
    int sphereCount,
    const Light *lights,
    int lightCount,
    const Camera &camera,
    const RenderConfig &config)
{
    for (int y = 0;
         y < config.height;
         ++y)
    {
        for (int x = 0;
             x < config.width;
             ++x)
        {
            Vec3 color(
                0.0f,
                0.0f,
                0.0f);

            for (int sample = 0;
                 sample < config.samples;
                 ++sample)
            {
                Ray ray =
                    camera.getRay(
                        x,
                        y,
                        config.width,
                        config.height);

                color +=
                    traceRay(
                        ray,
                        spheres,
                        sphereCount,
                        lights,
                        lightCount,
                        config.maxBounces);
            }

            framebuffer[y * config.width + x] =
                color /
                static_cast<float>(
                    config.samples);
        }
    }
}

void renderGPU(
    Vec3 *framebuffer,
    const Sphere *spheres,
    int sphereCount,
    const Light *lights,
    int lightCount,
    const Camera &camera,
    const RenderConfig &config)
{
    const size_t pixelBytes =
        static_cast<size_t>(
            config.width) *
        config.height *
        sizeof(Vec3);

    const size_t sphereBytes =
        static_cast<size_t>(
            sphereCount) *
        sizeof(Sphere);

    const size_t lightBytes =
        static_cast<size_t>(
            lightCount) *
        sizeof(Light);

    Vec3 *deviceFramebuffer =
        nullptr;

    Sphere *deviceSpheres =
        nullptr;

    Light *deviceLights =
        nullptr;

    checkCuda(
        cudaMalloc(
            &deviceFramebuffer,
            pixelBytes),
        "cudaMalloc framebuffer");

    checkCuda(
        cudaMalloc(
            &deviceSpheres,
            sphereBytes),
        "cudaMalloc spheres");

    checkCuda(
        cudaMalloc(
            &deviceLights,
            lightBytes),
        "cudaMalloc lights");

    checkCuda(
        cudaMemcpy(
            deviceSpheres,
            spheres,
            sphereBytes,
            cudaMemcpyHostToDevice),
        "copy spheres");

    checkCuda(
        cudaMemcpy(
            deviceLights,
            lights,
            lightBytes,
            cudaMemcpyHostToDevice),
        "copy lights");

    dim3 block(
        16,
        16);

    dim3 grid(
        (config.width +
         block.x - 1) /
            block.x,

        (config.height +
         block.y - 1) /
            block.y);

    renderKernel<<<grid, block>>>(
        deviceFramebuffer,
        deviceSpheres,
        sphereCount,
        deviceLights,
        lightCount,
        camera,
        config.width,
        config.height,
        config.samples,
        config.maxBounces);

    checkCuda(
        cudaGetLastError(),
        "kernel launch");

    checkCuda(
        cudaDeviceSynchronize(),
        "kernel synchronization");

    checkCuda(
        cudaMemcpy(
            framebuffer,
            deviceFramebuffer,
            pixelBytes,
            cudaMemcpyDeviceToHost),
        "copy framebuffer");

    cudaFree(
        deviceFramebuffer);

    cudaFree(
        deviceSpheres);

    cudaFree(
        deviceLights);
}
